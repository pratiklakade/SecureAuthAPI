﻿using APIDevelopmentinASP.NETCore.Model;
using APIDevelopmentinASP.NETCore.Services;
using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography;

namespace APIDevelopmentinASP.NETCore.Controllers
{
        [ApiController]
        [Route("api/[controller]")]
        public class AuthController : ControllerBase
        {
            private readonly JwtService _jwtService;

            // 🔁 Temporary in-memory user (will replace with DB later)
            private static User currentUser = new User
            {
                Username = "admin",
                Password = "1234"
            };

        public AuthController(JwtService jwtService)
        {
            _jwtService = jwtService;
        }

        private string GenerateRefreshToken()
        {
            var randomBytes = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomBytes);
                return Convert.ToBase64String(randomBytes);
            }
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] User user)
        {
            if (user.Username == currentUser.Username && user.Password == currentUser.Password)
            {
                var accessToken = _jwtService.GenerateToken(user);
                var refreshToken = GenerateRefreshToken();

                currentUser.RefreshToken = refreshToken;
                currentUser.RefreshTokenExpiryTime = DateTime.Now.AddMinutes(1);

                return Ok(new
                {
                    token = accessToken,
                    refreshToken = refreshToken
                });
            }

            return Unauthorized("Invalid credentials");
        }

        [HttpPost("refresh")]
        public IActionResult Refresh([FromBody] TokenModel tokenModel)
        {
            // Use currentUser to validate refresh token
            if (tokenModel.RefreshToken != currentUser.RefreshToken || currentUser.RefreshTokenExpiryTime <= DateTime.Now)
            {
                return Unauthorized("Invalid or expired refresh token.");
            }

            var newAccessToken = _jwtService.GenerateToken(currentUser);
            var newRefreshToken = GenerateRefreshToken();

            currentUser.RefreshToken = newRefreshToken;
            currentUser.RefreshTokenExpiryTime = DateTime.Now.AddMinutes(1);

            return Ok(new
            {
                token = newAccessToken,
                refreshToken = newRefreshToken
            });
        }
    }
}