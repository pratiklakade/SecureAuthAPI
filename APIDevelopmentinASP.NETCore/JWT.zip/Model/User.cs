﻿namespace APIDevelopmentinASP.NETCore.Model
{
    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }

        // New
        public string RefreshToken { get; set; }
        public DateTime RefreshTokenExpiryTime { get; set; }
    }
}
